import 'dart:ui';

const kPrimaryColor = Color(0xff62FCD7);
const kNotesBox = "notes_box";

const List<Color> colors = [
  Color(0xffAD7A99),
  Color(0xffB2CEDE),
  Color(0xff8CDFD6),
  Color(0xff6DC0D5),
  Color(0xff5A716A),
];
